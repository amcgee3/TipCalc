//
//  ViewController.swift
//  TipCalc
//
//  Created by Anthony McGee on 10/13/20.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var TipController: UISegmentedControl!
    @IBOutlet weak var billAmountTXT: UITextField!
    @IBOutlet weak var tipPercentageLBL: UILabel!
    @IBOutlet weak var totalLBL: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func onTap(_ sender: Any)
    {
        
    }
    
    @IBAction func calculateTip(_ sender: Any) {
        
        // Gets the bill value and initializes tip percentage values
        
        let bill = Double(billAmountTXT.text!) ?? 0
        let tipPercentages = [0.15, 0.18, 0.20]
        
        // Does calculations to output back to user
        
        let tip = bill * tipPercentages[TipController.selectedSegmentIndex]
        let total = bill + tip
        
        // Final Output
        
        tipPercentageLBL.text = String(format: "$%.2f", tip)
        totalLBL.text = String(format: "$%.2f", total)
        
    }
}

